This library has been taken from https://github.com/gabime/spdlog under MIT license.

GmmLib is using this library for logging to a file, log to debugger (Windows), 
log to logcat (Android) and log to syslog (Linux) with format similar to python print()
under Debug and Release Internal modes.
